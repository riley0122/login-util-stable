yes i know it looks like it was made in a hurry thats because i made basicly everything in between classes and in the bus

older versions than 0.0.4: https://pypi.org/manage/project/login-util/